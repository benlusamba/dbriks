#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2019 Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import threading
import unittest

from pyspark.databricks.testing.utils import wait_until

from pyspark.sql.tests import ScalarPandasUDFTests


class ScalarPandasUDFWithPrefetchTests(ScalarPandasUDFTests):

    @classmethod
    def setUpClass(cls):
        ScalarPandasUDFTests.setUpClass()

        cls.spark.conf.set("spark.sql.execution.arrow.maxRecordsPerBatch", 5)
        cls.spark.conf.set("spark.databricks.execution.pandasUDF.prefetch.enabled", True)
        cls.spark.conf.set("spark.databricks.execution.pandasUDF.prefetch.maxBatches", 1)

    def test_prefetch(self):
        """
        Test the prefetch by counting the number of active prefetch threads.

        The UDF will be called three times.
        In the first call, the thread will be waiting for the queue to be available.
        In the second call, the thread will finish because all the data are prefetched.
        """
        from pyspark.sql.functions import col, pandas_udf

        edgeModeEnabled = self.spark._jvm \
            .__getattr__('com.databricks.spark.DatabricksEdgeConfigs$') \
            .__getattr__('MODULE$') \
            .edgeModeEnabled()

        def count_threads(stop):
            cnt = [0]
            threads = [0]

            @pandas_udf('integer')
            def f(v):
                import pandas as pd
                if cnt[0] == 0:
                    threads[0] = threading.active_count()
                elif edgeModeEnabled and cnt[0] == stop:
                    wait_until(lambda: threading.active_count() < threads[0], 1, 0.01)
                cnt[0] += 1
                return pd.Series(threading.active_count())

            return f

        df = self.spark.range(12)  # 4 executors * 1 record per batch * 3 batches

        with self.sql_conf({
                "spark.sql.execution.arrow.maxRecordsPerBatch": 2 if edgeModeEnabled else 1,
                "spark.databricks.execution.pandasUDF.prefetch.maxBatches": 1}):
            result = df.select(count_threads(stop=2)(col('id'))).take(3)

            if edgeModeEnabled:
                # The third executions have one less threads than the first execution because
                # the prefetch thread will finish after the second execution.
                self.assertEqual(result[1][0], result[0][0])
                self.assertEqual(result[2][0], result[0][0] - 1)
            else:
                self.assertEqual(result[1][0], result[0][0])
                self.assertEqual(result[2][0], result[0][0])

        with self.sql_conf({
                "spark.sql.execution.arrow.maxRecordsPerBatch": 3 if edgeModeEnabled else 1,
                "spark.databricks.execution.pandasUDF.prefetch.maxBatches": 2}):
            result = df.select(count_threads(stop=1)(col('id'))).take(3)

            if edgeModeEnabled:
                # The second and third executions have one less threads than the first execution
                # because the prefetch thread will finish after the first execution.
                self.assertEqual(result[1][0], result[0][0] - 1)
                self.assertEqual(result[2][0], result[0][0] - 1)
            else:
                self.assertEqual(result[1][0], result[0][0])
                self.assertEqual(result[2][0], result[0][0])


if __name__ == "__main__":
    from pyspark.databricks.sql.tests.test_pandas_udf_prefetch import *

    try:
        import xmlrunner
        unittest.main(testRunner=xmlrunner.XMLTestRunner(output='target/test-reports'), verbosity=2)
    except ImportError:
        unittest.main(verbosity=2)
