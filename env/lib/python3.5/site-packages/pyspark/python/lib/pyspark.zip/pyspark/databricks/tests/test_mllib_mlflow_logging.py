#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2019 Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

from collections import namedtuple
import concurrent.futures
import contextlib
import numpy as np
from six import StringIO
import sys
import unittest
import warnings

from pyspark.databricks.testing.utils import UsageLoggingTestCase
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml.linalg import Vectors
from pyspark.ml.tuning import CrossValidator, TrainValidationSplit, ParamGridBuilder
from pyspark.ml import util
from pyspark.ml.util import _MLflowInstrumentation, _AsynchronousTaskQueue, _MLflowUsageLogger
from pyspark.testing.mlutils import MockMLflow, MockMlflowClient, MockMLflowTracking, MockMLflowUtil

# We have tests to make sure certain warning messages are printed. Setting the
# filter to "always" so that no warning messages would be suppressed.
warnings.simplefilter('always')


@contextlib.contextmanager
def captured_output():
    new_out = StringIO()
    old_out = sys.stdout
    try:
        sys.stdout = new_out
        yield sys.stdout
    finally:
        sys.stdout = old_out


def wait_for_mlflow():
    """
    Wait for mlflow logging
    """
    concurrent.futures.wait(_MLflowInstrumentation.async_task_queue.futures)


mocked_mlflow = MockMLflow()
mlflow_util = MockMLflowUtil
run_info_size = namedtuple('MLflowRun', ['num_params', 'num_metrics', 'num_tags', 'num_runs'])


class MLlibMLflowLoggingTests(UsageLoggingTestCase):

    def setUp(self):
        super(MLlibMLflowLoggingTests, self).setUp()
        util._mlflow = mocked_mlflow
        util._MlflowClient = MockMlflowClient
        util._get_experiment_id = mlflow_util._get_experiment_id
        _MLflowInstrumentation.mlflow_client = None

    def tearDown(self):
        mlflow_util.cleanup_tests()
        _MLflowInstrumentation.usage_logger = None
        super(MLlibMLflowLoggingTests, self).tearDown()

    def is_edge_mode_enabled(self):
        """
        Check whether edge mode is enabled
        """
        edgeModeEnabled = self.spark._jvm \
            .__getattr__('com.databricks.spark.DatabricksEdgeConfigs$') \
            .__getattr__('MODULE$') \
            .edgeModeEnabled()
        return edgeModeEnabled

    def assert_num_logs(self, num_logs, expected_num):
        """
        Assert that the number of records equals to expected_num.
        """
        self.assertEqual(num_logs, expected_num,
                         "Expected {e} usage record but found {n}."
                         .format(n=num_logs, e=expected_num))

    def check_run_info_size(self, expected_size):
        # Check number of mlflow.log_param calls
        num_params = mlflow_util.get_num_params()
        self.assertEqual(num_params,
                         expected_size.num_params,
                         "Wrong number of params logged in MLflow: Expected {e} but got {r}."
                         .format(e=expected_size.num_params, r=num_params))
        # Check number of mlflow.log_metric calls
        num_metrics = mlflow_util.get_num_metrics()
        self.assertEqual(num_metrics,
                         expected_size.num_metrics,
                         "Wrong number of metrics logged in MLflow: Expected {e} but got {r}."
                         .format(e=expected_size.num_metrics, r=num_metrics))
        # Check number of mlflow.set_tags calls
        num_tags = mlflow_util.get_num_tags()
        self.assertEqual(num_tags,
                         expected_size.num_tags,
                         "Wrong number of tags logged in MLflow: Expected {e} but got {r}."
                         .format(e=expected_size.num_tags, r=num_tags))
        num_runs = mlflow_util.get_num_runs()
        self.assertEqual(num_runs,
                         expected_size.num_runs,
                         "Wrong number of mlflow runs: Expected {e} but got {r}."
                         .format(e=expected_size.num_runs, r=num_runs))

    def check_run_info(self, run_uuid, expected_params, expected_metrics, expected_tags):
        # Check mlflow.log_param calls
        for param in expected_params:
            log_value = mlflow_util.get_param(run_uuid, param)
            self.assertEqual(log_value,
                             expected_params[param],
                             "Wrong value of param {n}: Expected {e} but got {r}."
                             .format(n=param, e=expected_params[param], r=log_value))

        # Check mlflow.log_metric calls
        for metric in expected_metrics:
            log_value = mlflow_util.get_metric(run_uuid, metric)
            self.assertEqual(log_value,
                             expected_metrics[metric],
                             "Wrong value of metric {n}: Expected {e} but got {r}."
                             .format(n=metric, e=expected_metrics[metric], r=log_value))
        # Check mlflow.set_tag calls
        for tag in expected_tags:
            log_value = mlflow_util.get_tag(run_uuid, tag)
            self.assertEqual(log_value,
                             expected_tags[tag],
                             "Wrong value of tag {n}: Expected {e} but got {r}."
                             .format(n=tag, e=expected_tags[tag], r=log_value))

    def test_log_single_run(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0]).build()
        param_to_name = {lr.maxIter: lr.maxIter.name}
        metric_names = ["test1", "test2"]
        metrics = np.array([1.0, 2.0])

        mlflow_logger = _MLflowInstrumentation()
        _MLflowInstrumentation.mlflow_client = MockMlflowClient()

        with mocked_mlflow.start_run() as active_run:
            run_uuid = active_run.info.run_uuid
            mlflow_logger._log_single_run(run_uuid, lr, grid[0], param_to_name,
                                          metric_names, metrics)
        wait_for_mlflow()

        expected_size = run_info_size(num_params=3, num_metrics=2, num_tags=1, num_runs=1)
        self.check_run_info_size(expected_size)

        expected_params = {"mlModelClass": type(lr).__name__,
                           "mlEstimatorUid": lr.uid,
                           lr.maxIter.name: 0}
        expected_metrics = {"test1": 1.0, "test2": 2.0}
        expected_tags = {"runSource": "mllibAutoTracking"}
        self.check_run_info(0, expected_params, expected_metrics, expected_tags)

    def test_log_tuning_runs(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0, 1]).build()
        metric_names = ["test1", "test2"]
        metrics = np.array([[1.0, 2.0], [3.0, 4.0]])

        mlflow_logger = _MLflowInstrumentation()
        _MLflowInstrumentation.mlflow_client = MockMlflowClient()
        with mocked_mlflow.start_run() as active_run:
            run_uuid = active_run.info.run_uuid
            fit_uuid = _MLflowInstrumentation._get_fit_uuid()
            mlflow_logger._log_tuning_runs(run_uuid, fit_uuid, lr, grid, metric_names, metrics)
        wait_for_mlflow()

        # tags: 2 child runs, each with 3 tags (parent ID, fit_uuid, runSource)
        expected_size = run_info_size(num_params=6, num_metrics=4, num_tags=6, num_runs=3)
        self.check_run_info_size(expected_size)

    def test_log_crossvalidator(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0, 1]).build()
        evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
        cv = CrossValidator(estimator=lr, estimatorParamMaps=grid, evaluator=evaluator, numFolds=4)
        metrics = np.array([[1.0, 2.0], [1.0, 2.0], [1.0, 4.0], [1.0, 4.0]])

        mlflow_logger = _MLflowInstrumentation()

        def run_log_crossvalidator():
            mlflow_logger.log_crossvalidator(cv, metrics)
            wait_for_mlflow()
        usage_records = self.track_usage(run_log_crossvalidator)

        # parent run tags: fit_uuid, runSource
        # child run tags: mlflow.parentRunId, fit_uuid, runSource
        expected_size = run_info_size(num_params=12, num_metrics=4, num_tags=8, num_runs=3)
        self.check_run_info_size(expected_size)

        expected_params = {'mlModelClass': "CrossValidator",
                           'mlEstimatorUid': cv.uid,
                           'estimator': type(lr).__name__,
                           'evaluator': type(evaluator).__name__,
                           'numFolds': 4,
                           'estimatorParamMapsLength': 2}
        self.check_run_info(0, expected_params, {}, {})

        # check we have logging the avg and std metrics
        expected_metrics = {"avg_accuracy": 1.0,
                            "std_accuracy": 0.0}
        self.check_run_info(1, {}, expected_metrics, {})

        expected_metrics = {"avg_accuracy": 3.0,
                            "std_accuracy": 1.0}
        self.check_run_info(2, {}, expected_metrics, {})

        # check Databricks usage logging
        self.assert_num_logs(len(usage_records), 1)
        self.assert_tag(usage_records[0],
                        self.tag_definitions().TAG_ML_UTIL_TYPE(),
                        'mllibAutoTracking')

    def test_log_trainvalidationsplit(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0, 1]).build()
        evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
        tvs = TrainValidationSplit(estimator=lr, estimatorParamMaps=grid, evaluator=evaluator)
        metrics = np.array([1.0, 2.0])

        mlflow_logger = _MLflowInstrumentation()

        def run_trainvalidationsplit():
            mlflow_logger.log_trainvalidationsplit(tvs, metrics)
            wait_for_mlflow()
        usage_records = self.track_usage(run_trainvalidationsplit)

        # parent run tags: fit_uuid, runSource
        # child run tags: mlflow.parentRunId, fit_uuid, runSource
        expected_size = run_info_size(num_params=11, num_metrics=2, num_tags=8, num_runs=3)
        self.check_run_info_size(expected_size)
        expected_params = {'mlModelClass': "TrainValidationSplit",
                           'mlEstimatorUid': tvs.uid,
                           'estimator': type(lr).__name__,
                           'evaluator': type(evaluator).__name__,
                           'estimatorParamMapsLength': 2}
        self.check_run_info(0, expected_params, {}, {})
        # check we have logging the avg and std metrics
        expected_metrics = {"accuracy": 1.0}
        self.check_run_info(1, {}, expected_metrics, {})
        expected_metrics = {"accuracy": 2.0}
        self.check_run_info(2, {}, expected_metrics, {})

        # check usage logging
        self.assert_num_logs(len(usage_records), 1)
        self.assert_tag(usage_records[0],
                        self.tag_definitions().TAG_ML_UTIL_TYPE(),
                        'mllibAutoTracking')

    def test_tvs_runs(self):
        self._test_training_runs(TrainValidationSplit)

    def test_cv_runs(self):
        self._test_training_runs(CrossValidator)

    def _set_up_data_and_estimator(self, model_class):
        dataset = self.spark.createDataFrame(
            [(Vectors.dense([0.0]), 0.0),
             (Vectors.dense([0.4]), 1.0),
             (Vectors.dense([0.5]), 0.0),
             (Vectors.dense([0.6]), 1.0),
             (Vectors.dense([1.0]), 1.0)] * 10,
            ["features", "label"])

        lr = LogisticRegression()
        grid = ParamGridBuilder().addGrid(lr.maxIter, [0, 1]).build()
        evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
        if model_class is CrossValidator:
            model = model_class(estimator=lr, estimatorParamMaps=grid,
                                evaluator=evaluator, numFolds=2)
        else:
            model = model_class(estimator=lr, estimatorParamMaps=grid, evaluator=evaluator)
        return dataset, model

    def _check_logs_for_fit(self, runs, expected_tuning_class, expected_parent_run_uuid=None,
                            expect_name_mangling=False):
        """
        Check MLflow logs for a single call to fit().  This matches _set_up_data_and_estimator,
        which tests 2 hyperparameter settings, thus generating 3 runs total.

        This can be used to check results for fit() calls which share parent runs
        by filtering the runs passed to this function.
        :param runs: List of runs, e.g., from `mlflow_util.get_run_list()`.
                     This should include exactly the set of runs corresponding to the 1 fit() call,
                     1 parent run and its child runs.
        :param expected_tuning_class: CrossValidator or TrainValidationSplit
        :param expected_parent_run_uuid: If not None, then confirm that this matches the parent run
                                         from logs.
        :param expect_name_mangling: If True, then expect the parent run to have its params and
                                     fit_uuid tag name-mangled with appended UUIDs.
                                     Child runs should not use name-mangling.
        """
        self.assertEqual(len(runs), 3,
                         "Expected to find {expected} MLflow runs but found {actual}"
                         .format(expected=3, actual=len(runs)))

        parent_runs = [r for r in runs if 'mlflow.parentRunId' not in r.data.tags]
        self.assertEqual(len(parent_runs), 1,
                         "Expected to find {expected} parent runs but found {actual}"
                         .format(expected=1, actual=len(parent_runs)))
        parent_run = parent_runs[0]
        if expected_parent_run_uuid is not None:
            self.assertEqual(
                parent_run.info.run_uuid, expected_parent_run_uuid,
                "Expected run with ID {expected} to be the parent but found {actual}"
                .format(expected=expected_parent_run_uuid, actual=parent_run.info.run_uuid))

        child_runs = [r for r in runs if 'mlflow.parentRunId' in r.data.tags]
        self.assertEqual(len(child_runs), 2,
                         "Expected to find {expected} child runs but found {actual}"
                         .format(expected=2, actual=len(child_runs)))

        fit_uuid = child_runs[0].data.tags['fit_uuid']

        # Check example params and tags, not all.
        expected_parent_params = {'mlModelClass': expected_tuning_class}
        expected_parent_tags = {'fit_uuid': fit_uuid}
        if expect_name_mangling:
            expected_parent_params =\
                dict([(p + '_' + fit_uuid, v) for p, v in expected_parent_params.items()])
            expected_parent_tags =\
                dict([(t + '_' + fit_uuid, v) for t, v in expected_parent_tags.items()])
        self.check_run_info(parent_run.info.run_uuid, expected_params=expected_parent_params,
                            expected_metrics={}, expected_tags=expected_parent_tags)

        expected_child_params = {'mlModelClass': 'LogisticRegression'}
        expected_child_tags = {'fit_uuid': fit_uuid}
        for child_run in child_runs:
            self.check_run_info(child_run.info.run_uuid, expected_params=expected_child_params,
                                expected_metrics={}, expected_tags=expected_child_tags)

    def _test_fit_once_without_active_run(self, dataset, model):
        model.fit(dataset)
        wait_for_mlflow()

        active_run = mocked_mlflow.active_run()
        self.assertIsNone(
            active_run,
            "Expected fit() without an existing active run to exit without leaving a run active, "
            "but found active run.")
        self._check_logs_for_fit(mlflow_util.get_run_list(),
                                 expected_tuning_class=type(model).__name__)

    def _test_fit_once_with_active_run(self, dataset, model):
        mocked_mlflow.set_tag("myFakeTag", "blah")  # start run
        model.fit(dataset)
        wait_for_mlflow()

        parent_run = mocked_mlflow.active_run()
        self.assertIsNotNone(
            parent_run,
            "Expected fit() to leave an existing active run still active, but found no active run "
            "after calling fit().")
        parent_run_uuid = parent_run.info.run_uuid
        self._check_logs_for_fit(mlflow_util.get_run_list(),
                                 expected_tuning_class=type(model).__name__,
                                 expected_parent_run_uuid=parent_run_uuid)

    def _test_fit_twice_with_active_run(self, dataset, model):
        # These should be logged under a shared parent run.
        # The second fit() call should use name-mangled params and tags.
        with mocked_mlflow.start_run() as parent_run:
            parent_run_uuid = parent_run.info.run_uuid
            model.fit(dataset)
            wait_for_mlflow()
            first_fit_run_uuids = [r.info.run_uuid for r in mlflow_util.get_run_list()]
            self._check_logs_for_fit(mlflow_util.get_run_list(),
                                     expected_tuning_class=type(model).__name__,
                                     expected_parent_run_uuid=parent_run_uuid)
            model.fit(dataset)
            wait_for_mlflow()

        second_fit_runs = mlflow_util.get_run_list(
            filter=lambda r: r.info.run_uuid not in first_fit_run_uuids or
            'mlflow.parentRunId' not in r.data.tags)
        self._check_logs_for_fit(second_fit_runs,
                                 expected_tuning_class=type(model).__name__,
                                 expected_parent_run_uuid=parent_run_uuid,
                                 expect_name_mangling=True)

    def _test_fit_twice_without_active_run(self, dataset, model):
        # These should be logged under 2 separate parent runs.
        # There should be no name-mangling of params and tags.
        model.fit(dataset)
        wait_for_mlflow()
        first_fit_runs = mlflow_util.get_run_list()
        first_fit_run_uuids = [r.info.run_uuid for r in first_fit_runs]
        self._check_logs_for_fit(mlflow_util.get_run_list(),
                                 expected_tuning_class=type(model).__name__)

        model.fit(dataset)
        wait_for_mlflow()
        second_fit_runs = [r for r in mlflow_util.get_run_list()
                           if r.info.run_uuid not in first_fit_run_uuids]
        self._check_logs_for_fit(second_fit_runs,
                                 expected_tuning_class=type(model).__name__)

    def test_mlflow_workflows(self):
        """
        This test checks various MLflow workflows and one or two fit() calls.
        It does not check all params, metrics and tags since those are checked in other unit tests;
        it focuses on making sure the MLflow run hierarchy meets expectations.
        """
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        def check_model_class(model_class):
            dataset, model = self._set_up_data_and_estimator(model_class)

            self._test_fit_once_without_active_run(dataset, model)
            mlflow_util.cleanup_tests()
            self._test_fit_once_with_active_run(dataset, model)
            mlflow_util.cleanup_tests()
            self._test_fit_twice_with_active_run(dataset, model)
            mlflow_util.cleanup_tests()
            self._test_fit_twice_without_active_run(dataset, model)
            mlflow_util.cleanup_tests()

        check_model_class(CrossValidator)
        check_model_class(TrainValidationSplit)

    def _test_training_runs(self, model_class):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        dataset, model = self._set_up_data_and_estimator(model_class)
        spark = dataset.sql_ctx.sparkSession

        def _run_and_check_warning(expected_out, expected_warning):
            with captured_output() as out:
                with warnings.catch_warnings(record=True) as warn:
                    model.fit(dataset)
                    wait_for_mlflow()
                    if expected_warning is not None:
                        self.assertEqual(
                            len(warn), 1,
                            "Expected a warning message but found none. Expected warning message: "
                            + expected_warning)
                        self.assertTrue(
                            expected_warning in str(warn[-1].message),
                            "Warning message should contain '{expected}' but did not.  Message: "
                            "{actual}".format(expected=expected_warning, actual=warn[-1].message))
                if expected_out is not None:
                    output = out.getvalue().strip()
                    self.assertTrue(
                        expected_out in output,
                        "Stdout should contain '{expected}' but did not.  Stdout: {actual}"
                        .format(expected=expected_out, actual=output))

        # Set `util._mlflow` and `util._MlflowClient` to be None.
        # This mimics the case without MLflow
        util._mlflow = None
        util._MlflowClient = None
        _run_and_check_warning(None, _MLflowInstrumentation._NO_MLFLOW_WARNING)
        self.assertEqual(mlflow_util.get_num_runs(),
                         0,
                         "There should be no MLflow logging without MLflow")

        # Test the case with MLflow, but with tracking feature-flagged off
        util._mlflow = mocked_mlflow
        util._MlflowClient = MockMlflowClient
        spark.conf.set(_MLflowInstrumentation._MLFLOW_TRACKING_ENABLED_FLAG, 'false')
        _run_and_check_warning(None, _MLflowInstrumentation._MLFLOW_TRACKING_DISABLED_MESSAGE)
        self.assertEqual(mlflow_util.get_num_runs(),
                         0,
                         "There should be no MLflow logging when feature flag is False")

        # Test the case with MLflow and tracking feature-flagged on
        spark.conf.set(_MLflowInstrumentation._MLFLOW_TRACKING_ENABLED_FLAG, 'true')
        _run_and_check_warning(_MLflowInstrumentation._HAVE_MLFLOW_MESSAGE, None)
        self.assertEqual(mlflow_util.get_num_runs(), 3,
                         "Expected to find {expected} MLflow runs but found {actual}"
                         .format(expected=3, actual=mlflow_util.get_num_runs()))

        # Test the case with MLflow, with feature flag on, but with server unreachable
        try:
            MockMlflowClient.disable_server = True
            _run_and_check_warning(
                None,
                _MLflowInstrumentation._MLFLOW_UNREACHABLE_WARNING
                .format(uri=MockMLflowTracking.fake_uri))
        finally:
            MockMlflowClient.disable_server = False

        # ML-7651: Databricks Jobs do not have valid experiment IDs set currently (though this will
        # change in the future).  This tests that we fail gracefully when the ID is invalid.
        orig_default_experiment_id = MockMLflowUtil.default_experiment_id
        try:
            MockMLflowUtil.default_experiment_id = 0
            _run_and_check_warning(
                None,
                _MLflowInstrumentation._INVALID_EXPERIMENT_ID_WARNING.format(id=0))

            MockMLflowUtil.default_experiment_id = '0'
            _run_and_check_warning(
                None,
                _MLflowInstrumentation._INVALID_EXPERIMENT_ID_WARNING.format(id='0'))
        finally:
            MockMLflowUtil.default_experiment_id = orig_default_experiment_id

    def test_resolve_param_names(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        def compare_dicts(expected, resolved):
            self.assertEqual(
                len(expected), len(resolved),
                "Expected Param name dict had length {e}, but resolved had length {r}".format(
                    e=len(expected), r=len(resolved)))
            for p, expected_name in expected.items():
                self.assertEqual(
                    expected_name, resolved[p],
                    "Wrong Param name: Expected {e} but found {r}".format(
                        e=expected_name, r=resolved[p]))

        # Test: No duplicate Params
        lr1 = LogisticRegression()
        params1 = [lr1.maxIter, lr1.regParam]
        resolved1 = _MLflowInstrumentation._resolve_param_names(params1)
        expected1 = {
            lr1.maxIter: 'maxIter',
            lr1.regParam: 'regParam',
        }
        compare_dicts(expected1, resolved1)

        # Test: Duplicate Param names
        lr2 = LogisticRegression()
        params2 = [lr1.maxIter, lr1.regParam, lr2.maxIter]
        resolved2 = _MLflowInstrumentation._resolve_param_names(params2)
        expected2 = {
            lr1.maxIter: lr1.uid + '.maxIter',
            lr1.regParam: 'regParam',
            lr2.maxIter: lr2.uid + '.maxIter',
        }
        compare_dicts(expected2, resolved2)

    def test_async_call(self):
        # skip the test in apache spark mode
        if not self.is_edge_mode_enabled():
            return

        async_task_queue = _AsynchronousTaskQueue()

        # test function with exceptions: like no mlflow servce
        def func_with_error(run_uuid, tuning, metrics):
            raise RuntimeError('test failure')

        _MLflowInstrumentation.usage_logger = _MLflowUsageLogger()

        def check_async_call():
            with warnings.catch_warnings(record=True) as warn:
                async_task_queue.call(
                    async_task_func=_MLflowInstrumentation._func_call_catch_exception,
                    func=func_with_error,
                    run_uuid=0,
                    tuning=0,
                    metrics=0)
                concurrent.futures.wait(async_task_queue.futures)
                warn_out = warn
            self.assertEqual(
                len(warn_out), 1,
                "There should be one warning message when throwing errors in the async call, "
                "but there were {actual}.".format(actual=len(warn)))
            self.assertTrue("RuntimeError" in str(warn[-1].message),
                            "Wrong warning message in function call with exception.")
            self.assertTrue("_func_call_catch_exception" in str(warn[-1].message),
                            "In function call with exception, warnings failed to include "
                            "the stack trace.")

        usage_records = self.track_usage(check_async_call)
        # check usage_log
        self.assert_num_logs(len(usage_records), 1)
        self.assert_tag(usage_records[0],
                        self.tag_definitions().TAG_ML_UTIL_TYPE(),
                        'mllibAutoTracking')
        self.assert_tag(usage_records[0],
                        self.tag_definitions().TAG_ERROR(),
                        "RuntimeError")
        self.assert_tag(usage_records[0],
                        self.tag_definitions().TAG_ERROR_MESSAGE(),
                        "test failure")


if __name__ == "__main__":
    from pyspark.databricks.tests.test_mllib_mlflow_logging import *

    try:
        import xmlrunner
        testRunner = xmlrunner.XMLTestRunner(output='target/test-reports')
    except ImportError:
        testRunner = None
    unittest.main(testRunner=testRunner, verbosity=2)
