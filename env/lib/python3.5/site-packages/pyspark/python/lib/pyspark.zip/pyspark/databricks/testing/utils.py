#
# DATABRICKS CONFIDENTIAL & PROPRIETARY
# __________________
#
# Copyright 2019 Databricks, Inc.
# All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains the property of Databricks, Inc.
# and its suppliers, if any.  The intellectual and technical concepts contained herein are
# proprietary to Databricks, Inc. and its suppliers and may be covered by U.S. and foreign Patents,
# patents in process, and are protected by trade secret and/or copyright law. Dissemination, use,
# or reproduction of this information is strictly forbidden unless prior written permission is
# obtained from Databricks, Inc.
#
# If you view or obtain a copy of this information and believe Databricks, Inc. may not have
# intended it to be made available, please promptly report it to Databricks Legal Department
# @ legal@databricks.com.
#

import time

from pyspark.testing.mlutils import SparkSessionTestCase


def wait_until(predicate, timeout_secs, check_interval_secs):
    """Waits until certain condition met or raises timeout error."""
    end_time = time.time() + timeout_secs
    while time.time() < end_time:
        if predicate():
            return
        time.sleep(check_interval_secs)
    raise RuntimeError("Timed out waiting for %s secs" % timeout_secs)


class UsageLoggingTestCase(SparkSessionTestCase):
    """
    This test class provides helpers for testing Databricks usage logging from Python.
    """

    def setUp(self):
        super(UsageLoggingTestCase, self).setUp()
        self._usage_logging = self.sc._jvm.com.databricks.spark.util.PythonUsageLoggingImpl()
        self._usage_logging_testing =\
            self.sc._jvm.com.databricks.spark.util.PythonUsageLoggingTestUtil()

    def track_usage(self, f):
        """
        Run a given function, recording usage logs.
        WARNING: This method should NOT be used in concurrent tests.

        :param f: Function which produces usage logs
        :return: List of (Scala) `UsageRecord`s which can be inspected manually or
                 using helpers methods in this class.
        """
        self._usage_logging_testing.startTracking()
        try:
            f()
        finally:
            records = self._usage_logging_testing.endTracking()
        return records

    def assert_tag(self, record, tag_definition, value):
        """
        Assert that the given record contains the given tag,value pair.
        """
        self.assertTrue(self._usage_logging_testing.checkTag(record, tag_definition, value),
                        "Expected usage log record to contain tag {tag} with value {value},"
                        " but found record: {record}".format(tag=tag_definition.name(),
                                                             value=value,
                                                             record=record.toString()))

    def tag_definitions(self):
        """Provides a handle to the Scala TagDefinitions object"""
        return self._usage_logging.tagDefinitions()

    def metric_definitions(self):
        """Provides a handle to the Scala MetricDefinitions object"""
        return self._usage_logging.metricDefinitions()
